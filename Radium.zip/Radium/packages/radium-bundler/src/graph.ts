export function buildGraph(entry: string) {
  return { entry, deps: [] };
}
