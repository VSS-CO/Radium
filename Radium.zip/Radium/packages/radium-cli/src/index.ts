#!/usr/bin/env node
import { createProject } from "./create.ts";

createProject();
