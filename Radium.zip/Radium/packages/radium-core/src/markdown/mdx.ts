export function compileMDX(src: string) {
  return `<!-- MDX compiled placeholder -->`;
}
