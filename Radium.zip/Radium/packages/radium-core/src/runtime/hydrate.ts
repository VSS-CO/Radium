export function hydrateIslands() {
  // TODO: real island hydration
  console.log("Radium: Hydrating islands...");
}
