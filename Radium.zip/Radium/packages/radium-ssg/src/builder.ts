export async function buildStaticSite() {
  console.log("Radium: SSG build start...");
}
