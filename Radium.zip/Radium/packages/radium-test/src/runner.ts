export function runTests() {
  console.log("Running Radium tests...");
}
