export function optimizeBundle(bundle: any) {
  return bundle;
}
