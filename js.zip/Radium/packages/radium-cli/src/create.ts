import { banner } from "./banner.js";

export async function createProject() {
  console.log(banner());
  console.log("Scaffolding new Radium project...");
}
