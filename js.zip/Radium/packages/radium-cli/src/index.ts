#!/usr/bin/env node
import { createProject } from "./create.js";

createProject();
