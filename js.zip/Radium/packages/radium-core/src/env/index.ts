export function loadEnv() {
  return process.env;
}
