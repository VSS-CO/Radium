export function compileMarkdown(src: string) {
  return `<p>${src}</p>`;
}
