export async function optimizeImage(file: string) {
  return file; // TODO real pipeline
}
