export function matchRoute(path: string) {
  // TODO: match incoming request to route module
  return null;
}
