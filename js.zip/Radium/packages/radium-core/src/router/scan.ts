export function scanRoutes(dir: string) {
  // TODO: read fs & map routes -> files
  return [];
}
