export function renderHTML(html: string) {
  return `<!DOCTYPE html>\n${html}`;
}
