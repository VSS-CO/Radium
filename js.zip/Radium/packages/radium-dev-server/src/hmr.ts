export function sendHMRUpdate(file: string) {
  console.log("HMR update:", file);
}
