export function startSSRServer() {
  console.log("Radium SSR server started.");
}
